# Game Mode by KOSI..FFX🇳🇬

A small, non-root Android gaming control app focused on a clean game-session experience.

## What it does

- Starts Free Fire or Free Fire MAX when installed.
- Enables Android Do Not Disturb priority mode when the user has granted notification-policy access.
- Stores the previous interruption filter and restores it when Game Mode ends.
- Provides a floating KOSI control bubble above the game after the user grants Android overlay permission.
- Provides a floating panel with WhatsApp launch, panel close, and Game Mode end controls.
- Reads Android thermal status where the platform exposes it.
- Opens battery and display settings from the main screen.
- Uses no account, backend, network connection, root access, sensitivity database, or fake CPU/GPU controls.

## What it deliberately does not claim

A normal third-party Android application cannot force Free Fire's CPU/GPU clocks, change Free Fire's scheduler priority, or obtain OEM-only Game Turbo privileges. This project does not include fake controls for those operations.

WhatsApp is launched as the real WhatsApp application. Whether the phone presents WhatsApp as a floating window is controlled by Android/HyperOS and the device's own window-management features.

## Build

The project uses Android Gradle Plugin 8.9.2, compile/target SDK 35, and Java 17. Android's AGP 8.9 documentation specifies Gradle 8.11.1 and JDK 17 for this plugin line.

A GitHub Actions workflow builds a debug APK with Gradle 8.11.1.

## Permissions

- `SYSTEM_ALERT_WINDOW`: required for the floating game control.
- `ACCESS_NOTIFICATION_POLICY`: required only if the user wants Game Mode to change Do Not Disturb.
- `POST_NOTIFICATIONS`: used for the foreground-service notification on Android versions that require notification permission.
- `FOREGROUND_SERVICE` and `FOREGROUND_SERVICE_SPECIAL_USE`: used while the user has an active floating Game Mode session.
