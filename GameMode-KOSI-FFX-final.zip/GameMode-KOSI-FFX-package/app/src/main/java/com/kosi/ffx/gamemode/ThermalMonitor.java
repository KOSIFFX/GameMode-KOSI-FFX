package com.kosi.ffx.gamemode;

import android.content.Context;
import android.os.Build;
import android.os.PowerManager;

public final class ThermalMonitor {
    private ThermalMonitor() {}

    public static int status(Context context) {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        if (pm == null || Build.VERSION.SDK_INT < 29) return PowerManager.THERMAL_STATUS_NONE;
        return pm.getCurrentThermalStatus();
    }

    public static String describe(Context context) {
        int value = status(context);
        if (Build.VERSION.SDK_INT < 29) return "not exposed by this Android version";
        switch (value) {
            case PowerManager.THERMAL_STATUS_NONE: return "normal";
            case PowerManager.THERMAL_STATUS_LIGHT: return "light";
            case PowerManager.THERMAL_STATUS_MODERATE: return "moderate";
            case PowerManager.THERMAL_STATUS_SEVERE: return "severe";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "critical";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "emergency";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "shutdown risk";
            default: return "unknown";
        }
    }
}
