package com.kosi.ffx.gamemode;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private static final int NOTIFICATION_REQUEST = 1001;
    private TextView status;
    private TextView thermal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(11, 12, 16));
        window.setNavigationBarColor(Color.rgb(11, 12, 16));
        buildUi();
        requestNotificationPermission();
        updateStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(getColor(R.color.kosi_bg));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(34), dp(24), dp(34));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("GAME MODE", 30, true);
        root.addView(title, margin(0, 0, 0, 2));
        TextView brand = text("by KOSI..FFX🇳🇬", 16, false);
        brand.setTextColor(getColor(R.color.kosi_muted));
        root.addView(brand, margin(0, 0, 0, 28));

        TextView cardTitle = text("Ready to play", 22, true);
        root.addView(cardTitle, margin(0, 0, 0, 6));
        status = text("Game Mode is off", 15, false);
        status.setTextColor(getColor(R.color.kosi_muted));
        root.addView(status, margin(0, 0, 0, 18));

        Button start = button("START GAME MODE");
        root.addView(start, margin(0, 0, 0, 12));
        start.setOnClickListener(v -> startGameMode());

        Button overlay = button("FLOATING GAME MODE");
        root.addView(overlay, margin(0, 0, 0, 12));
        overlay.setOnClickListener(v -> startOverlayOnly());

        Button dnd = button("DO NOT DISTURB ACCESS");
        root.addView(dnd, margin(0, 0, 0, 24));
        dnd.setOnClickListener(v -> openDndSettings());

        TextView section = text("SESSION", 13, true);
        section.setTextColor(getColor(R.color.kosi_muted));
        root.addView(section, margin(0, 0, 0, 8));

        thermal = text("Thermal status: checking…", 14, false);
        thermal.setTextColor(getColor(R.color.kosi_text));
        root.addView(thermal, margin(0, 0, 0, 18));

        TextView info = text(
                "Game Mode keeps the controls simple: launch the game, reduce interruptions, keep the floating control available, and watch for thermal stress. It does not claim root access or direct CPU/GPU control.",
                14, false);
        info.setTextColor(getColor(R.color.kosi_muted));
        root.addView(info, margin(0, 0, 0, 24));

        Button battery = button("BATTERY SETTINGS");
        root.addView(battery, margin(0, 0, 0, 10));
        battery.setOnClickListener(v -> safeStart(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));

        Button display = button("DISPLAY SETTINGS");
        root.addView(display, margin(0, 0, 0, 10));
        display.setOnClickListener(v -> safeStart(new Intent(Settings.ACTION_DISPLAY_SETTINGS)));

        Button stop = button("STOP GAME MODE");
        root.addView(stop, margin(0, 0, 0, 4));
        stop.setOnClickListener(v -> stopGameMode());
    }

    private void startGameMode() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings();
            toast("Allow Game Mode to display over other apps, then press START again.");
            return;
        }
        GameOverlayService.start(this);
        int thermal = ThermalMonitor.status(this);
        if (Build.VERSION.SDK_INT >= 29 && thermal >= android.os.PowerManager.THERMAL_STATUS_SEVERE) {
            toast("The phone is reporting high thermal stress. Game Mode will not force extra performance.");
        }
        boolean launched = FreeFireLauncher.launch(this);
        status.setText(launched ? "Game Mode active • Free Fire launched" : "Game Mode active • Free Fire not installed");
    }

    private void startOverlayOnly() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlaySettings();
            toast("Allow display over other apps, then press FLOATING GAME MODE again.");
            return;
        }
        GameOverlayService.start(this);
        status.setText("Floating Game Mode active");
    }

    private void stopGameMode() {
        GameOverlayService.stop(this);
        status.setText("Game Mode is off");
    }

    private void updateStatus() {
        thermal.setText("Thermal status: " + ThermalMonitor.describe(this));
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_REQUEST);
        }
    }

    private void openOverlaySettings() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        safeStart(intent);
    }

    private void openDndSettings() {
        safeStart(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
    }

    private void safeStart(Intent intent) {
        try {
            startActivity(intent);
        } catch (Exception e) {
            toast("This settings page is not available on this Android build.");
        }
    }

    private TextView text(String value, int size, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(getColor(R.color.kosi_text));
        view.setGravity(Gravity.START);
        if (bold) view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        return view;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(13);
        button.setTextColor(getColor(R.color.kosi_accent_text));
        button.setAllCaps(false);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(52));
        button.setPadding(dp(16), 0, dp(16), 0);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(getColor(R.color.kosi_accent));
        bg.setCornerRadius(dp(18));
        button.setBackground(bg);
        return button;
    }

    private LinearLayout.LayoutParams margin(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void toast(String value) { Toast.makeText(this, value, Toast.LENGTH_LONG).show(); }
}
