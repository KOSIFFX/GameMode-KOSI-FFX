package com.kosi.ffx.gamemode;

import android.app.NotificationManager;
import android.content.Context;
import android.os.PowerManager;

public final class GameSessionController {
    private final Context context;
    private final NotificationManager notificationManager;
    private Integer previousInterruptionFilter;
    private boolean changedFilter;
    private final android.content.SharedPreferences prefs;

    public GameSessionController(Context context) {
        this.context = context.getApplicationContext();
        this.notificationManager = (NotificationManager) this.context.getSystemService(Context.NOTIFICATION_SERVICE);
        this.prefs = this.context.getSharedPreferences("game_session", Context.MODE_PRIVATE);
    }

    public boolean hasDndAccess() {
        return notificationManager != null && notificationManager.isNotificationPolicyAccessGranted();
    }

    public boolean enableFocus() {
        if (!hasDndAccess()) return false;
        if (previousInterruptionFilter == null) {
            previousInterruptionFilter = notificationManager.getCurrentInterruptionFilter();
            prefs.edit().putInt("previous_filter", previousInterruptionFilter).putBoolean("active", true).apply();
        }
        try {
            notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
            changedFilter = true;
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }

    public void restoreFocus() {
        if (!hasDndAccess() || !changedFilter || previousInterruptionFilter == null) return;
        try {
            notificationManager.setInterruptionFilter(previousInterruptionFilter);
        } catch (SecurityException ignored) {
        }
        changedFilter = false;
        previousInterruptionFilter = null;
        prefs.edit().remove("previous_filter").putBoolean("active", false).apply();
    }

    public void restoreStaleSession() {
        if (!prefs.getBoolean("active", false) || !hasDndAccess()) return;
        int previous = prefs.getInt("previous_filter", NotificationManager.INTERRUPTION_FILTER_ALL);
        try {
            notificationManager.setInterruptionFilter(previous);
        } catch (SecurityException ignored) {
        }
        prefs.edit().remove("previous_filter").putBoolean("active", false).apply();
    }

    public boolean isPowerSaverOn() {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        return pm != null && pm.isPowerSaveMode();
    }
}
