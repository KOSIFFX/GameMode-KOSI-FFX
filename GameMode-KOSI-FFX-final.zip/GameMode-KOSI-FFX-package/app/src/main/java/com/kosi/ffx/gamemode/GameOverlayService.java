package com.kosi.ffx.gamemode;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public final class GameOverlayService extends Service {
    private static final String ACTION_START = "com.kosi.ffx.gamemode.START";
    private static final String ACTION_STOP = "com.kosi.ffx.gamemode.STOP";
    private static final int NOTIFICATION_ID = 42;
    private WindowManager windowManager;
    private View bubble;
    private View panel;
    private TextView thermalLabel;
    private PowerManager.OnThermalStatusChangedListener thermalListener;
    private GameSessionController session;

    public static void start(Context context) {
        Intent intent = new Intent(context, GameOverlayService.class).setAction(ACTION_START);
        context.startService(intent);
    }

    public static void stop(Context context) {
        Intent intent = new Intent(context, GameOverlayService.class).setAction(ACTION_STOP);
        context.startService(intent);
    }

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        session = new GameSessionController(this);
        session.restoreStaleSession();
        session.enableFocus();
        registerThermalListener();
        createNotificationChannel();
        showBubble();
        startForeground(NOTIFICATION_ID, buildNotification());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) stopSelf();
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        remove(panel);
        remove(bubble);
        unregisterThermalListener();
        session.restoreFocus();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private void showBubble() {
        if (!Settings.canDrawOverlays(this) || bubble != null) return;
        TextView view = new TextView(this);
        view.setText("K");
        view.setTextSize(17);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setTextColor(Color.rgb(11, 12, 16));
        view.setGravity(Gravity.CENTER);
        view.setBackgroundResource(R.drawable.overlay_bubble);
        view.setElevation(dp(8));

        final WindowManager.LayoutParams lp = overlayParams(dp(62), dp(62));
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(14);
        lp.y = dp(180);
        view.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = lp.x; startY = lp.y; moved = false; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) moved = true;
                    lp.x = startX - (int) dx; lp.y = startY + (int) dy;
                    windowManager.updateViewLayout(view, lp); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (!moved) togglePanel(); return true;
                }
                return true;
            }
        });
        bubble = view;
        windowManager.addView(view, lp);
    }

    private void togglePanel() {
        if (panel == null) showPanel(); else { remove(panel); panel = null; }
    }

    private void showPanel() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.setBackgroundResource(R.drawable.overlay_panel);
        root.setElevation(dp(12));

        TextView title = label("GAME MODE", 20, true);
        root.addView(title, row());
        TextView subtitle = label("KOSI..FFX🇳🇬", 13, false);
        subtitle.setTextColor(Color.LTGRAY);
        root.addView(subtitle, row());

        thermalLabel = label("Thermal: " + ThermalMonitor.describe(this), 13, false);
        thermalLabel.setTextColor(Color.LTGRAY);
        root.addView(thermalLabel, rowBottom(10));

        root.addView(action("WHATSAPP", v -> openWhatsApp()), rowBottom(8));
        root.addView(action("CLOSE PANEL", v -> { remove(panel); panel = null; }), rowBottom(8));
        root.addView(action("END GAME MODE", v -> stopSelf()), row());

        WindowManager.LayoutParams lp = overlayParams(dp(290), WindowManager.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = dp(16);
        lp.y = dp(250);
        panel = root;
        windowManager.addView(root, lp);
    }

    private TextView label(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(Color.WHITE);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private TextView action(String value, View.OnClickListener listener) {
        TextView t = label(value, 13, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(12), dp(10), dp(12));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Color.WHITE); bg.setCornerRadius(dp(14));
        t.setTextColor(Color.rgb(11, 12, 16)); t.setBackground(bg); t.setOnClickListener(listener);
        return t;
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    private LinearLayout.LayoutParams row() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams rowBottom(int bottom) { LinearLayout.LayoutParams p = row(); p.setMargins(0, 0, 0, dp(bottom)); return p; }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void registerThermalListener() {
        if (Build.VERSION.SDK_INT < 29) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null) return;
        thermalListener = status -> {
            String text = "Thermal: " + ThermalMonitor.describe(this);
            if (thermalLabel != null) thermalLabel.post(() -> {
                thermalLabel.setText(text);
                if (status >= PowerManager.THERMAL_STATUS_SEVERE) {
                    thermalLabel.setTextColor(Color.rgb(255, 184, 77));
                } else {
                    thermalLabel.setTextColor(Color.LTGRAY);
                }
            });
        };
        pm.addThermalStatusListener(getMainExecutor(), thermalListener);
    }

    private void unregisterThermalListener() {
        if (Build.VERSION.SDK_INT < 29 || thermalListener == null) return;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) pm.removeThermalStatusListener(thermalListener);
        thermalListener = null;
    }

    private void openWhatsApp() {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
        if (intent == null) { Toast.makeText(this, "WhatsApp is not installed.", Toast.LENGTH_SHORT).show(); return; }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, "game_mode")
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Game Mode is active")
                .setContentText("Floating controls are ready")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("game_mode", "Game Mode", NotificationManager.IMPORTANCE_LOW));
        }
    }

    private void remove(View view) {
        if (view != null && windowManager != null) {
            try { windowManager.removeView(view); } catch (Exception ignored) {}
        }
    }
}
