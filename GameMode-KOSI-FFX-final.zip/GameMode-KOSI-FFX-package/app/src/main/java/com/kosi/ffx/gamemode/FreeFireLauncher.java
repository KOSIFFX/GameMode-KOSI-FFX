package com.kosi.ffx.gamemode;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

public final class FreeFireLauncher {
    private static final String[] PACKAGES = {"com.dts.freefiremax", "com.dts.freefireth"};

    private FreeFireLauncher() {}

    public static boolean launch(Context context) {
        PackageManager pm = context.getPackageManager();
        for (String pkg : PACKAGES) {
            Intent launch = pm.getLaunchIntentForPackage(pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launch);
                return true;
            }
        }
        return false;
    }
}
