package com.kosi.ffx.gamemode;

import android.content.Context;
import android.os.Build;
import android.os.PowerManager;

public final class ThermalMonitor {
    private final PowerManager powerManager;

    public ThermalMonitor(Context context) {
        powerManager = (PowerManager) context.getApplicationContext().getSystemService(Context.POWER_SERVICE);
    }

    public int status() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && powerManager != null) {
            return powerManager.getCurrentThermalStatus();
        }
        return PowerManager.THERMAL_STATUS_NONE;
    }

    public String label() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return "Not exposed by Android";
        switch (status()) {
            case PowerManager.THERMAL_STATUS_LIGHT: return "Light";
            case PowerManager.THERMAL_STATUS_MODERATE: return "Moderate";
            case PowerManager.THERMAL_STATUS_SEVERE: return "Severe";
            case PowerManager.THERMAL_STATUS_CRITICAL: return "Critical";
            case PowerManager.THERMAL_STATUS_EMERGENCY: return "Emergency";
            case PowerManager.THERMAL_STATUS_SHUTDOWN: return "Shutdown";
            default: return "Normal";
        }
    }

    public boolean isHigh() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                && status() >= PowerManager.THERMAL_STATUS_SEVERE;
    }
}
