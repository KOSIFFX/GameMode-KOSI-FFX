package com.kosi.ffx.gamemode;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private final ArrayList<GameItem> games = new ArrayList<>();
    private SharedPreferences prefs;
    private TextView status;
    private Button autoButton;
    private GameAdapter adapter;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("games", MODE_PRIVATE);
        buildUi();
        requestNotificationPermission();
        loadGames();
        refreshStatus();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(18));
        root.setBackgroundColor(Color.rgb(11, 12, 16));

        TextView title = text("GAME MODE", 30, Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);
        root.addView(text("by KOSI..FFX🇳🇬", 14, Color.LTGRAY));

        status = text("Checking Game Mode…", 13, Color.LTGRAY);
        root.addView(status);
        space(root, 12);

        autoButton = button("ENABLE AUTO GAME MODE");
        autoButton.setOnClickListener(v -> toggleAuto());
        root.addView(autoButton);

        Button dnd = button("DO NOT DISTURB ACCESS");
        dnd.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)));
        root.addView(dnd);

        Button overlay = button("FLOATING CONTROL ACCESS");
        overlay.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        root.addView(overlay);

        Button usage = button("GAME DETECTION ACCESS");
        usage.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
            } catch (Exception e) {
                Toast.makeText(this,
                        "Open Settings > Special app access > Usage access.",
                        Toast.LENGTH_LONG).show();
            }
        });
        root.addView(usage);

        Button launch = button("LAUNCH SELECTED GAME");
        launch.setOnClickListener(v -> launchSelected());
        root.addView(launch);

        Button stop = button("STOP GAME MODE");
        stop.setOnClickListener(v -> {
            prefs.edit().putBoolean("auto", false).apply();
            GameOverlayService.stop(this);
            refreshStatus();
        });
        root.addView(stop);

        space(root, 14);
        TextView library = text("MY GAMES", 17, Color.WHITE);
        library.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(library);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setBackgroundColor(Color.TRANSPARENT);
        adapter = new GameAdapter(this, games);
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

        setContentView(root);
    }

    private void loadGames() {
        games.clear();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        for (ApplicationInfo app : apps) {
            if (app.packageName.equals(getPackageName())) continue;
            if (pm.getLaunchIntentForPackage(app.packageName) == null) continue;

            boolean isGame = app.category == ApplicationInfo.CATEGORY_GAME;
            games.add(new GameItem(
                    app.packageName,
                    String.valueOf(pm.getApplicationLabel(app)),
                    isGame));
        }

        Collections.sort(games, new Comparator<GameItem>() {
            @Override public int compare(GameItem a, GameItem b) {
                return a.name.compareToIgnoreCase(b.name);
            }
        });

        Set<String> selected =
                new HashSet<>(prefs.getStringSet("selected", new HashSet<String>()));

        if (selected.isEmpty()) {
            for (GameItem g : games) {
                if (g.isGame) selected.add(g.packageName);
            }
            prefs.edit().putStringSet("selected", selected).apply();
        }

        for (GameItem g : games) {
            g.selected = selected.contains(g.packageName);
        }

        adapter.notifyDataSetChanged();
    }

    private void toggleAuto() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this,
                    "Grant Floating Control access first.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        if (!hasUsageAccess()) {
            Toast.makeText(this,
                    "Grant Game Detection access first.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        boolean enabled = prefs.getBoolean("auto", false);
        prefs.edit().putBoolean("auto", !enabled).apply();

        if (!enabled) {
            Intent i = new Intent(this, GameOverlayService.class);
            i.putExtra("auto_mode", true);
            startForegroundServiceCompat(i);
        } else {
            GameOverlayService.stop(this);
        }

        refreshStatus();
    }

    private void launchSelected() {
        GameItem chosen = null;
        for (GameItem g : games) {
            if (g.selected) {
                chosen = g;
                break;
            }
        }

        if (chosen == null) {
            Toast.makeText(this, "Select a game first.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this,
                    "Grant Floating Control access first.",
                    Toast.LENGTH_LONG).show();
            return;
        }

        Intent service = new Intent(this, GameOverlayService.class);
        service.putExtra("auto_mode", false);
        service.putExtra(GameOverlayService.EXTRA_PACKAGE, chosen.packageName);
        startForegroundServiceCompat(service);

        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(chosen.packageName);
            if (launch == null) throw new IllegalStateException();
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this,
                    "This game could not be launched.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void startForegroundServiceCompat(Intent i) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
        else startService(i);
    }

    private boolean hasUsageAccess() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(APP_OPS_SERVICE);
        int mode;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mode = appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
        } else {
            mode = appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private void refreshStatus() {
        if (autoButton == null || status == null) return;
        boolean auto = prefs.getBoolean("auto", false);
        autoButton.setText(auto
                ? "AUTO GAME MODE: ON"
                : "ENABLE AUTO GAME MODE");

        status.setText((auto ? "Auto detection is ON" : "Ready")
                + " • Thermal: " + new ThermalMonitor(this).label());
    }

    @Override protected void onResume() {
        super.onResume();
        if (prefs != null) {
            refreshStatus();
            if (adapter != null) {
                Set<String> selected =
                        prefs.getStringSet("selected", new HashSet<String>());
                for (GameItem g : games) g.selected = selected.contains(g.packageName);
                adapter.notifyDataSetChanged();
            }
        }
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(13);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(29, 32, 40));
        bg.setCornerRadius(dp(18));
        b.setBackground(bg);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(-1, dp(50));
        lp.setMargins(0, dp(4), 0, dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private void space(LinearLayout root, int h) {
        View v = new View(this);
        root.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private static final class GameItem {
        final String packageName;
        final String name;
        final boolean isGame;
        boolean selected;

        GameItem(String packageName, String name, boolean isGame) {
            this.packageName = packageName;
            this.name = name;
            this.isGame = isGame;
        }
    }

    private final class GameAdapter extends ArrayAdapter<GameItem> {
        GameAdapter(Context c, ArrayList<GameItem> items) {
            super(c, android.R.layout.simple_list_item_multiple_choice, items);
        }

        @Override public View getView(
                int position, View convertView, android.view.ViewGroup parent) {

            CheckBox box = new CheckBox(MainActivity.this);
            GameItem item = getItem(position);

            box.setText(item.name);
            box.setTextColor(Color.WHITE);
            box.setTextSize(15);
            box.setPadding(dp(8), dp(8), dp(8), dp(8));
            box.setChecked(item.selected);

            box.setOnCheckedChangeListener((buttonView, checked) -> {
                item.selected = checked;
                Set<String> selected =
                        new HashSet<>(prefs.getStringSet(
                                "selected", new HashSet<String>()));

                if (checked) selected.add(item.packageName);
                else selected.remove(item.packageName);

                prefs.edit().putStringSet("selected", selected).apply();
            });

            return box;
        }
    }
}
