package com.kosi.ffx.gamemode;

import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;

public final class GameSessionController {
    private static final String PREFS = "game_session";
    private static final String KEY_ACTIVE = "active";
    private static final String KEY_FILTER = "previous_filter";

    private final NotificationManager notificationManager;
    private final SharedPreferences prefs;

    public GameSessionController(Context context) {
        Context app = context.getApplicationContext();
        notificationManager = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean hasDndAccess() {
        return notificationManager != null && notificationManager.isNotificationPolicyAccessGranted();
    }

    public void enableFocus() {
        if (!hasDndAccess()) return;
        if (!prefs.getBoolean(KEY_ACTIVE, false)) {
            prefs.edit()
                    .putBoolean(KEY_ACTIVE, true)
                    .putInt(KEY_FILTER, notificationManager.getCurrentInterruptionFilter())
                    .apply();
        }
        notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY);
    }

    public void restoreFocus() {
        if (!hasDndAccess()) {
            prefs.edit().clear().apply();
            return;
        }
        if (prefs.getBoolean(KEY_ACTIVE, false)) {
            int previous = prefs.getInt(KEY_FILTER, NotificationManager.INTERRUPTION_FILTER_ALL);
            notificationManager.setInterruptionFilter(previous);
        }
        prefs.edit().clear().apply();
    }

    public void restoreStaleSession() {
        if (prefs.getBoolean(KEY_ACTIVE, false)) restoreFocus();
    }
}
