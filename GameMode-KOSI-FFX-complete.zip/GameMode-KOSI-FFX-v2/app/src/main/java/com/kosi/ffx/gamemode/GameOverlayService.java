package com.kosi.ffx.gamemode;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GameOverlayService extends Service {
    public static final String ACTION_STOP = "com.kosi.ffx.gamemode.STOP";
    public static final String EXTRA_PACKAGE = "game_package";
    private static final int NOTIFICATION_ID = 4101;
    private static final String CHANNEL_ID = "game_mode";

    private WindowManager windowManager;
    private View bubble;
    private View panel;
    private TextView thermalText;
    private TextView gameText;
    private GameSessionController sessionController;
    private ThermalMonitor thermalMonitor;
    private Handler handler;
    private Runnable foregroundCheck;
    private String activeGamePackage;
    private boolean sessionActive;
    private boolean autoMode;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        sessionController = new GameSessionController(this);
        sessionController.restoreStaleSession();
        thermalMonitor = new ThermalMonitor(this);
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Game Mode ready"));
        startForegroundDetection();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        autoMode = intent == null || intent.getBooleanExtra("auto_mode", true);
        String requested = intent == null ? null : intent.getStringExtra(EXTRA_PACKAGE);
        if (requested != null) beginSession(requested);
        return START_NOT_STICKY;
    }

    private void startForegroundDetection() {
        foregroundCheck = new Runnable() {
            @Override public void run() {
                String foreground = getForegroundPackage();
                if (foreground != null) {
                    if (!sessionActive && autoMode && isSelectedGame(foreground)) {
                        beginSession(foreground);
                    } else if (sessionActive
                            && activeGamePackage != null
                            && !foreground.equals(activeGamePackage)
                            && !foreground.equals(getPackageName())) {
                        endSession();
                    }
                }
                updatePanel();
                handler.postDelayed(this, 1200L);
            }
        };
        handler.post(foregroundCheck);
    }

    private boolean isSelectedGame(String pkg) {
        SharedPreferences p = getSharedPreferences("games", MODE_PRIVATE);
        Set<String> selected = p.getStringSet("selected", new HashSet<String>());
        return selected.contains(pkg);
    }

    private String getForegroundPackage() {
        try {
            UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = usm.queryUsageStats(
                    UsageStatsManager.INTERVAL_BEST, now - 5000, now);
            if (stats == null || stats.isEmpty()) return null;
            UsageStats best = null;
            for (UsageStats s : stats) {
                if (best == null || s.getLastTimeUsed() > best.getLastTimeUsed()) best = s;
            }
            return best == null ? null : best.getPackageName();
        } catch (Exception ignored) {
            return null;
        }
    }

    private void beginSession(String packageName) {
        activeGamePackage = packageName;
        sessionActive = true;
        if (sessionController.hasDndAccess()) sessionController.enableFocus();
        showBubble();
        updatePanel();
        updateNotification();
    }

    private void endSession() {
        sessionActive = false;
        activeGamePackage = null;
        removePanel();
        removeBubble();
        sessionController.restoreFocus();
        updateNotification();
    }

    private void showBubble() {
        if (!Settings.canDrawOverlays(this) || bubble != null) return;

        TextView v = new TextView(this);
        v.setText("K");
        v.setTextColor(Color.rgb(11, 12, 16));
        v.setTextSize(18);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(null, android.graphics.Typeface.BOLD);
        v.setBackgroundResource(R.drawable.overlay_bubble);

        WindowManager.LayoutParams lp = overlayParams(54, 54);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = 20;
        lp.y = 220;

        v.setOnTouchListener(new View.OnTouchListener() {
            final float[] down = new float[2];
            final int[] start = new int[2];
            @Override public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    down[0] = event.getRawX();
                    down[1] = event.getRawY();
                    start[0] = lp.x;
                    start[1] = lp.y;
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = start[0] - (int)(event.getRawX() - down[0]);
                    lp.y = start[1] + (int)(event.getRawY() - down[1]);
                    try { windowManager.updateViewLayout(view, lp); } catch (Exception ignored) {}
                    return true;
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (Math.abs(event.getRawX() - down[0]) < 12 &&
                            Math.abs(event.getRawY() - down[1]) < 12) {
                        togglePanel();
                    }
                    return true;
                }
                return false;
            }
        });

        windowManager.addView(v, lp);
        bubble = v;
    }

    private WindowManager.LayoutParams overlayParams(int w, int h) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(
                dp(w), dp(h), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
    }

    private void togglePanel() {
        if (panel == null) showPanel();
        else removePanel();
    }

    private void showPanel() {
        if (!Settings.canDrawOverlays(this) || panel != null) return;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));
        root.setBackgroundResource(R.drawable.overlay_panel);

        TextView title = text("GAME MODE", 20, Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);
        root.addView(text("by KOSI..FFX🇳🇬", 13, Color.LTGRAY));

        gameText = text("Game: " + (activeGamePackage == null ? "Ready" : activeGamePackage), 13, Color.WHITE);
        thermalText = text("Thermal: " + thermalMonitor.label(), 13,
                thermalMonitor.isHigh() ? Color.rgb(255,183,77) : Color.LTGRAY);
        root.addView(gameText);
        root.addView(thermalText);

        Button whatsapp = button("WHATSAPP");
        whatsapp.setOnClickListener(v -> launchWhatsApp());
        root.addView(whatsapp);

        Button close = button("CLOSE PANEL");
        close.setOnClickListener(v -> removePanel());
        root.addView(close);

        Button end = button("END GAME MODE");
        end.setOnClickListener(v -> stopSelf());
        root.addView(end);

        WindowManager.LayoutParams lp = overlayParams(300, 0);
        lp.width = dp(300);
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.gravity = Gravity.CENTER;
        lp.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;

        windowManager.addView(root, lp);
        panel = root;
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(0, dp(4), 0, dp(4));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(13);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(29, 32, 40));
        bg.setCornerRadius(dp(18));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.setMargins(0, dp(4), 0, dp(4));
        b.setLayoutParams(lp);
        return b;
    }

    private void launchWhatsApp() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            }
        } catch (Exception ignored) {}
    }

    private void updatePanel() {
        if (thermalText != null) {
            thermalText.setText("Thermal: " + thermalMonitor.label());
            thermalText.setTextColor(thermalMonitor.isHigh()
                    ? Color.rgb(255, 183, 77) : Color.LTGRAY);
        }
        if (gameText != null && activeGamePackage != null) {
            gameText.setText("Game: " + activeGamePackage);
        }
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, buildNotification(
                    sessionActive ? "Gaming session active" : "Game Mode ready"));
        }
    }

    private Notification buildNotification(String text) {
        Intent i = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return b.setContentTitle("Game Mode by KOSI..FFX🇳🇬")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.notification_channel_name),
                    NotificationManager.IMPORTANCE_LOW);
            c.setDescription(getString(R.string.notification_channel_description));
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(c);
        }
    }

    private void removePanel() {
        if (panel != null) {
            try { windowManager.removeView(panel); } catch (Exception ignored) {}
            panel = null;
        }
    }

    private void removeBubble() {
        if (bubble != null) {
            try { windowManager.removeView(bubble); } catch (Exception ignored) {}
            bubble = null;
        }
    }

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    @Override public void onDestroy() {
        if (handler != null && foregroundCheck != null) handler.removeCallbacks(foregroundCheck);
        endSession();
        removePanel();
        removeBubble();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, GameOverlayService.class));
    }
}
