# Game Mode by KOSI..FFX🇳🇬

A native Android Game Mode designed as a general gaming hub, not a Free Fire-only tool.

## Core features

- General installed-game library.
- User-selectable games.
- Manual game launch.
- Optional automatic foreground-game detection using Android Usage Access.
- Real floating game-mode control using `SYSTEM_ALERT_WINDOW`.
- Gaming Focus / Do Not Disturb using Android Notification Policy Access.
- Real Android thermal awareness using `PowerManager`.
- WhatsApp launch button from the floating control.
- Previous DND/interruption state restoration.
- No root.
- No account.
- No Supabase, Base44, or Firebase.
- No sensitivity/DPI/device-profile system.
- No fake RAM/CPU/GPU boosting.

## Android limitations

A normal third-party Android app cannot directly control another app's CPU/GPU clocks, kernel scheduler priority, OEM Game Turbo internals, or thermal governor. This project does not pretend to do those things.

Automatic game detection uses Android Usage Access and therefore depends on the permission and the behavior of the device's Android/HyperOS version.

WhatsApp is launched as the real WhatsApp app. Whether HyperOS displays it as a floating window is controlled by the operating system.

## Build

The included GitHub Actions workflow builds a debug APK using:
- Java 17
- Gradle 8.13
- Android SDK 35
- Android Gradle Plugin 8.9.2

GitHub Actions artifact:
`GameMode-KOSI-FFX-debug-apk`

Application ID:
`com.kosi.ffx.gamemode`

Display name:
`Game Mode by KOSI..FFX🇳🇬`
